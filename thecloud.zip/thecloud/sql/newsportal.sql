-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2019 at 12:28 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newsportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int(11) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`, `CreationDate`, `UpdationDate`) VALUES
(1, 'admin', '$2y$12$JqiNjMujogooiBQGea/9POq7B0i7ALZilaxZxzIQn5Hcaz1mWZXWK', 'halimaaktherkakoly@gmail.com', 1, '2018-05-27 17:51:00', '2019-12-13 21:14:42');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `id` int(11) NOT NULL,
  `CategoryName` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`id`, `CategoryName`, `Description`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(9, 'News', 'all Kind of news', '2019-12-13 21:58:58', NULL, 1),
(10, 'world', 'countries', '2019-12-13 21:59:28', NULL, 1),
(11, 'business', 'business', '2019-12-13 21:59:47', NULL, 1),
(13, 'Sports', 'Sports', '2019-12-13 22:00:22', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcomments`
--

CREATE TABLE `tblcomments` (
  `id` int(11) NOT NULL,
  `postId` char(11) DEFAULT NULL,
  `name` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `comment` mediumtext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcomments`
--

INSERT INTO `tblcomments` (`id`, `postId`, `name`, `email`, `comment`, `postingDate`, `status`) VALUES
(1, '12', 'Anuj', 'anuj@gmail.com', 'Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.', '2018-11-21 11:06:22', 0),
(2, '12', 'Test user', 'test@gmail.com', 'This is sample text for testing.', '2018-11-21 11:25:56', 1),
(3, '7', 'ABC', 'abc@test.com', 'This is sample text for testing.', '2018-11-21 11:27:06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `PageName` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `Description` longtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `PageName`, `PageTitle`, `Description`, `PostingDate`, `UpdationDate`) VALUES
(1, 'aboutus', 'About News Portal', '<p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; text-align: justify; white-space: pre-line;\">Bangladesh is changing. It is time for a new generation of Bangladeshis to be heard, for their vision for our country to be promoted. THE CLOUD is here to be the platform for that new voice, and new vision.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; text-align: justify; white-space: pre-line;\">The editorial team is totally committed to delivering accurate and impartial news with the aim of informing the public debate and enabling Bangladeshis to make educated choices.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; text-align: justify; white-space: pre-line;\">Our pledge to those we serve is to seek the truth, deliver the facts and offer relevant context and analysis where appropriate.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; text-align: justify; white-space: pre-line;\">Our tone will be non-judgemental, objective and fair. We aim to include all relevant opinions and ensure that no significant strand of thought is neglected.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; text-align: justify; white-space: pre-line;\">We will strive to dig where others donâ€™t, give voice to the voiceless. We all hold all quarters who bear a public responsibility â€“ government, corporates, NGOâ€™s and many others â€“ accountable on behalf of you, our audience, and indeed all citizens.<br style=\"margin: 0px; padding: 0px;\">We aim to practice journalism that is professional, reliable, dependable and transparent.</p>', '2018-06-30 18:01:03', '2019-12-13 22:33:03'),
(2, 'contactus', 'Contact Details', '<p><br></p><p><b>Address :&nbsp; Sector 6,</b> Uttara Model Town, Uttara, Dhaka</p><p><b>Phone Number : </b>+880112233445566</p><p><b>Email -id : </b>halimaaktherkakolyl@gmail.com</p>', '2018-06-30 18:01:36', '2019-12-13 22:34:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblposts`
--

CREATE TABLE `tblposts` (
  `id` int(11) NOT NULL,
  `PostTitle` longtext DEFAULT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `SubCategoryId` int(11) DEFAULT NULL,
  `PostDetails` longtext CHARACTER SET utf8 DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `Is_Active` int(1) DEFAULT NULL,
  `PostUrl` mediumtext DEFAULT NULL,
  `PostImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblposts`
--

INSERT INTO `tblposts` (`id`, `PostTitle`, `CategoryId`, `SubCategoryId`, `PostDetails`, `PostingDate`, `UpdationDate`, `Is_Active`, `PostUrl`, `PostImage`) VALUES
(13, 'When will the killing fields be identified?', 9, 11, '<div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">Among the victims of their brutality, only a few had been identified while many bodies were too decomposed to be traced for identification</p></div><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The nine-month-long bloody war in 1971, saw the Pakistani occupation army and its local collaborators - al-Badr, al-Shams and razakars abducting intellectuals and killing them in many places across Bangladesh.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">During the Liberation War, Chowdhury Mueen Uddin and Ashrafuzzaman Khan and their fellows played the central role behind the killing of intellectuals of the country, mainly the teachers, doctors, journalists and writers with an intention to cripple the nation intellectually.</p>', '2019-12-13 22:06:30', NULL, 1, 'When-will-the-killing-fields-be-identified?', '4efdd2f969559e8b1c92e99f32ded48e.jpg'),
(14, 'Quader: Politics does not mean trading', 9, 12, '<div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">He urged the party men to take preparation for the city corporation election</p></div><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><a href=\"https://www.dhakatribune.com/bangladesh/politics/2019/12/12/awami-league-holds-council-in-28-districts-in-just-22-days\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"margin: 0px; padding: 0px; color: rgb(255, 0, 0);\">Awami League</a> General Secretary Obaidul Quader has said politics should not be trade-oriented to earn money for oneself.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">He also said politicians should work for the welfare of the country and its people with honesty and devotion.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">â€œOne must make sacrifice in politics. Politics should not be used to earn money for oneself,â€ he said this while addressing an extended meeting of Dhaka City South Awami League at the partyâ€™s central office in Bangabandhu Avenue on Friday.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><a href=\"http://dhakatribune.com/bangladesh/politics/2019/12/12/quader-govt-has-nothing-to-do-with-khaleda-s-case\" rel=\"noopener noreferrer\" target=\"_blank\" style=\"margin: 0px; padding: 0px; color: rgb(255, 0, 0);\">Quader</a>, also Road Transport and Bridges Minister, urged the party leaders and workers to do politics to establish the ideology of Father of the Nation Bangabandhu Sheikh Mujibur Rahman, reports BSS.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">He said the government under the leadership of Prime Minister Sheikh Hasina is taking ahead the country to build a \"Sonar Bangla\" as dreamt by Bangabandhu.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The Awami League general secretary urged Dhaka City South Awami League to bring devoted, honest and able workers in the party leaderships.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">â€œWorkers are the heart of Awami League. We should keep in mind that the workers should not get hurt by our behaviours,â€ he added.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">He urged the party men to take preparation for the city corporation election.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">â€œWe will have to conduct mass-contact at thana and ward levels to highlight the development activities and achievements of the government,â€ he added.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Chaired by Dhaka City South Awami League President Abu Ahmed Mannafi, the function was addressed by Awami League Organizing Secretary and Deputy Minister for Education Barrister Mohibul Hasan Chowdhury Nowfel and Dhaka City South Awami League General Secretary Humayun Kabir, among others.</p>', '2019-12-13 22:08:23', NULL, 1, 'Quader:-Politics-does-not-mean-trading', '3fb5ed13afe8714a7e5d13ee506003dd.jpg'),
(16, 'Most wanted criminal Zeesan arrested in Dubai', 9, 13, '<p><br></p><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">&nbsp;</span></p><div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">The extradition process is underway</p></div><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">A most wanted criminal, Zeesan alias Zeesan Ahmed alias Ali Akbar Chowdhury has been arrested in Dubai, and Bangladesh police have already initiated the process to bring him back to the country.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Zeesan has long been a fugitive from Bangladesh due to his involvement in various criminal activities, including the murder of policemen, and extortion.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">News of Zeesanâ€™s arrest in the United Arab Emirates (UAE) surfaced on Wednesday. According to transnational police organization Interpol, he has been charged with murder, and possession of explosives.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Mohiur Rahman, assistant inspector general (AIG) of the National Central Bureau (NCB) of Interpol at police headquarters in Dhaka, said Zeesan was arrested last week with the help of NCB Interpol Dubai. The arrest was confirmed on Thursday.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">NCB Interpol Dhaka has already started the process to bring Zeesan back to his home country, the AIG added.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Zeesan is wanted in connection with the murder of two officers of the Detective Branch (DB) of Police at a hotel in Malibagh in 2003. He fled to India in 2007, and later on ended up in Dubai. He has reportedly been controlling criminal activities in Bangladesh from the Middle East.&nbsp;</p>', '2019-12-13 22:18:31', NULL, 1, 'Most-wanted-criminal-Zeesan-arrested-in-Dubai', 'f99687dd719c4e8bc6a39e946c3d9ef7.jpg'),
(17, 'Six dead, including a cop and two suspects, in New Jersey shooting', 10, 16, '<p><br></p><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">&nbsp;</span></p><div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">The two gunmen and three civilian victims were pronounced dead inside the JC Kosher Supermarket</p></div><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Six people, including a police officer and two suspected gunmen, were killed in an hours-long shootout that unfolded on Tuesday afternoon near a cemetery and a kosher grocery store in Jersey City, New Jersey, police said.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The two suspects killed acted alone, Jersey City Police Chief Michael Kelly told a news conference hours later in the stateâ€™s second-largest city, which sits directly across the Hudson River from Manhattan.</p>', '2019-12-13 22:27:13', NULL, 1, 'Six-dead,-including-a-cop-and-two-suspects,-in-New-Jersey-shooting', '135007e7085979a7d5b41ce54c0e54d7.jpg'),
(18, 'Dhaka beat Cumilla by 20 runs', 13, 17, '<div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">Tamim Iqbal led the way with his knock, off 53 balls, including half a dozen fours and four eye-catching sixes, while Thisara Perera hammered an unbeaten 17-ball 42, with seven boundaries</p></div><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Dhaka Platoon registered their first victory in the Bangabandhu Bangladesh Premier League Twenty20, riding on a fine 74 from Tamim Iqbal, as they beat Cumilla Warriors by 20 runs at Mirpur Sher-e-Bangla National Cricket Stadium in Dhaka Friday.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Dhaka, who lost their opening game against Rajshahi Royals at the same venue Thursday, posted a challenging 180 losing seven wickets in their stipulated 20 overs.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Tamim led the way with his knock, off 53 balls, including half a dozen fours and four eye-catching sixes, while Thisara Perera hammered an unbeaten 17-ball 42, with seven boundaries.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Cumilla captain Dasun Shanaka and Soumya Sarkar bagged two wickets apiece.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">In reply, Cumilla were restricted to 160 for the loss of nine wickets in their allotted 20 overs, despite valiant knocks from Dawid Malan (40), Mahidul Islam Ankon (37), Soumya Sarkar (35) and Bhanuka Rajapaksa (29).</p>', '2019-12-13 22:28:27', NULL, 1, 'Dhaka-beat-Cumilla-by-20-runs', 'fac4ef5554f69012fe38d2f1d4e245a6.jpg'),
(19, 'Argentine Lavezzi retires', 13, 18, '<p><br></p><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">&nbsp;</span></p><div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">Ezequiel Lavezzi played 51 times for Argentina and was in the starting lineup when they lost the 2014 World Cup final to Germany</p></div><p><span style=\"font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Argentine international forward Ezequiel Lavezzi confirmed Friday that he was retiring from playing at the age of 34, ending \"the most amazing phase life has given me.\"</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Lavezzi played 51 times for Argentina and was in the starting lineup when they lost the 2014 World Cup final to Germany.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">He played five seasons at Napoli and five at Paris Saint-Germain before finishing his career in Hebei Fortune in China where he was, when he arrived, the highest-paid player in the world.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: Roboto, sans-serif, &quot;Siyam Rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Lavezzi made his last appearance for Heibei on November 27, scoring as the team lost to champion Evergrande in the penultimate round of the season.&nbsp;</p>', '2019-12-13 22:29:22', NULL, 1, 'Argentine-Lavezzi-retires', 'e4bde0eb46b8f32ef4b4207f5344b4d4.jpg'),
(20, 'Mustard, a â€˜profit cropâ€™ for Benapole farmers', 9, 11, '<div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">Officials at the Department of Agriculture Extension (DAE) say they hope the mustard cultivators will make better profit this year</p></div><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The high-yielding mustard seeds from Bangladesh Agriculture Research Institute (BARI) have given farmers in Sharsha upazila of Jessore something to be cheerful about after years of low yield.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Mustard has been cultivated on a record amount of field in the upazila this season. The vast mustard fields are also attracting bees, and farmers are optimistic about a buoyant production of both mustard and honey.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">A key reason that encouraged the record cultivation is the high value for mustard seeds in the local markets.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Officials at the Department of Agriculture Extension (DAE) say they hope the mustard cultivators will make better profit this year.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">DAE is observing the cultivation on 1,500 hectares in 11 unions of Sharsha upazila, which 200 hectares more than the previous year.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Farmers have cultivated high-yielding mustard seeds including BARI-14, BARI-9, BINA-9/10, Sharisha-15, Shonali Sharisha (SS-75) and local TORI-7.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Low-yielding mustard variety discouraged many farmers from cultivating them over the years but high-yielding BARI-14 is changing the trend.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Crop from this newly-invented variety can be harvested in less than 80 days. The yield per hectare is about 1,500kg. After mustard is cultivated, Boro seeds can be sown on those fields ensuring optimum use of croplands.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">â€œIâ€™ve sown BARI-14 and BINA-9/10 varieties on two bigha. It cost me Tk3,000 to Tk4,000 per bigha,â€ said Nazrul Islam, a farmer of Shamolagachi village in the upazila. â€œIâ€™m expecting bumper production.â€</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Mohiuddin, a farmer from Sharshaâ€™s Ghiba village, said the DAE officials are encouraging them to cultivate mustard. â€œPaddy cultivation is quite good on the mustard fields and it costs less for Boro farming as well,â€ he said.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Sharsha DAE official Soutom Kumar Sheel said they are providing necessary advice to the farmers. â€œMustard is recognized as a profit crop as they can go for Boro farming after its harvest,â€ he said.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Since the plants of BARI-14 variety are long, their leaves fall on the ground and act as organic fertilizer, he described adding that less fertiliser is needed for Boro if it is cultivated after mustard.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">â€œThis year, weâ€™ve so far helped 900 farmers in the upazila with ingredients for mustard cultivation. We expect a good yield this time,â€ he added.</p>', '2019-12-13 23:01:35', '2019-12-13 23:05:26', 1, 'Mustard,-a-â€˜profit-cropâ€™-for-Benapole-farmers', '86c3cbc8cde622a8c725d89a88bdcb96.jpg'),
(21, 'Tennis federation GS in hot water', 13, 19, '<p><br></p><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">&nbsp;</span></p><div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">Morshed was removed from his post Thursday</p></div><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">A case was filed against Bangladesh Tennis Federation general secretary Golam Morshed Wednesday for the accusation of sexual harassment against a Bangladeshi-origin American teenaged tennis player earlier this month.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Victimâ€™s uncle, Hira Lal, filed the case under The Prevention of Women and Children Repression Act 2000 at Gulshan Police Station in Dhaka.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Morshed was removed from his post Thursday.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">According to the plaintiffâ€™s statement, the expatriate tennis player visited Bangladesh from the USA at the beginning of the month in order to participate in two International Tennis Federation junior tournaments.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">She was accommodated at Dhaka Club rest house.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">On November 4, Morshed offered her to have dinner and while riding on the car, Morshed sexually abused her, and also used abusive words.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The 16-year old girl felt unsecure while staying in Rajshahi for a tournament and left the country for the United States on November 14 without participating in two tournaments, including one in Khulna.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Gulshan Police Station inspector SM Kaium informed that the investigation is going on in this regard after the case was filed, and that they are trying to capture the offender.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Morshed has been removed by the federation for the misconduct and National Sports Council secretary, Masud Karim, will act as the BTF general secretary.</p>', '2019-12-13 23:04:47', NULL, 1, 'Tennis-federation-GS-in-hot-water', 'ae566253288191ce5d879e51dae1d8c3.jpg'),
(22, 'USAID launches Comprehensive Private Sector Assessment', 9, 14, '<div class=\"highlighted-content\" style=\"margin: 0px; padding: 0px; font-size: 20px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\"><p style=\"margin-bottom: 1rem; padding: 0px;\">6 sectors can help country to fetch $ 60bn in 2023</p></div><p><span style=\"font-family: roboto, sans-serif, &quot;siyam rupali&quot;; font-size: 16px; letter-spacing: 0.5px; white-space: pre-line;\">\r\n</span></p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The United States, through the US Agency of International Development (USAID), will provide financial assistance to Bangladesh to help diversify exports and stimulate new streams of economic growth.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">To materialize the objective, the USAID has identified six priority sectors. They are agribusiness (food processing), health care, information and communications technology and outsourcing, light engineering, pharmaceuticals and tourism as most promising industries beyond the ready-made garment (RMG) sector for private sector engagement and investment over the next course of development actions.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">A USAID report titled Comprehensive Private Sector Assessment (PSA) identified the sectors. &nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Mutasir Tahmeed Chowdhury of Inspira Advocacy and Consultancy Ltd presented the report.&nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The report suggests that more concentration should be given on the six sectors which have the potential to add value to the export basket to earn more than $ 60 billion by 2023.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The report suggests systematic diversification towards productive, value added, and export-oriented sectors is imperative to address the current state of unemployment and inclusive growth.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The PSA was launched at American Chamber of Commerce in Bangladesh (Amcham) yesterday.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The PSA, conducted between October 2018 and July 2019 by Inspira Advocacy and Consultancy Ltd, a Bangladeshi private consultation firm, examined 16 emerging sectors in total, which also included ceramics, entrepreneurship, leather and leather goods, medical equipment, plastic, renewable energy and energy efficiency, shipbuilding, shrimp and fish, telecommunications, and vehicle assembly. &nbsp;</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">The PSAâ€™s findings aimed to support the government of Bangladeshâ€™s economic diversification reforms initiative and help the private sector deepen its engagement with the government and other stakeholders in order to further promote Bangladeshâ€™s economic growth.</p><p style=\"margin-bottom: 1rem; padding: 0px; font-size: 16px; font-family: roboto, sans-serif, &quot;siyam rupali&quot;; letter-spacing: 0.5px; white-space: pre-line;\">Executive Chairman of the BIDA Sirajul Islam, USAID Deputy Administrator Bonnie Glick, Deputy Chief of Mission of the US Embassy JoAnne Wagner and Bangladesh Mission Director of the USAID Derrick Brown also spoke on the occasion.</p>', '2019-12-13 23:07:52', NULL, 1, 'USAID-launches-Comprehensive-Private-Sector-Assessment', 'cdc679bebbe282e170ab6fe0dca8445e.jpg'),
(23, 'Bangladesh reworks Bangla calendar to match national days with West', 9, 11, '<div class=\"widget storyContent article widget-editable viziwyg-section-37 inpage-widget-29 article_lead_text\" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 10px 0px; font-family: arial, sans-serif; line-height: 18px;\"><h5 class=\" print-only\" style=\"font-variant-numeric: normal; font-variant-east-asian: normal; font-weight: bold; font-stretch: normal; font-size: 13px; line-height: normal; font-family: Arial, Verdana, Helvetica, sans-serif; margin-top: 0px; margin-bottom: 15px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; padding: 0px;\">The Bangladesh government has revised the Bangla calendar to match the national days with the Western calendar.</h5></div><div class=\"widget ad googlead widget-editable viziwyg-section-2 inpage-widget-1454364\" style=\"overflow: visible; border: 0px; outline-style: initial; outline-width: 0px; font-size: 16px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px; font-family: Helvetica, Arial;\"><div align=\"center\" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px;\"><div id=\"div-gpt-ad-1517400187384-0\" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px; height: 90px; width: 640px;\"></div></div></div><div class=\"floatingContent-right \" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; font-size: 16px; vertical-align: baseline; background: transparent; margin: 0px 0px 0px 15px; padding: 0px; font-family: Helvetica, Arial; float: right; clear: both; width: 140px;\"><div class=\"widget storyContent article widget-editable viziwyg-section-37 inpage-widget-28\" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px;\"></div></div><div class=\"floatingContent-right \" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; font-size: 16px; vertical-align: baseline; background: transparent; margin: 0px 0px 0px 15px; padding: 0px; font-family: Helvetica, Arial; float: right; clear: both; width: 140px;\"></div><div class=\"floatingContent-right \" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; font-size: 16px; vertical-align: baseline; background: transparent; margin: 0px 0px 0px 15px; padding: 0px; font-family: Helvetica, Arial; float: right; clear: both; width: 140px;\"></div><div class=\"floatingContent-right \" style=\"overflow: hidden; border: 0px; outline-style: initial; outline-width: 0px; font-size: 16px; vertical-align: baseline; background: transparent; margin: 0px 0px 0px 15px; padding: 0px; font-family: Helvetica, Arial; float: right; clear: both; width: 140px;\"></div><div class=\"wrappingContent \" style=\"overflow: visible; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px; font-family: arial, sans-serif; line-height: 18px; color: rgb(21, 21, 21);\"><div class=\"widget storyContent article widget-editable viziwyg-section-37 inpage-widget-21 article_body\" style=\"overflow: visible; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px; line-height: 18px;\"><div class=\"custombody print-only\" style=\"overflow: visible; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; margin: 0px; padding: 0px; line-height: 18px;\"><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The change has made Ashwin a 31-day month, which means Kartik will start on Thursday and the season of Hemanta is delayed by a day as the revised calendar went into effect from Wednesday.&nbsp;&nbsp;</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">Some newspapers, however, missed the revision and published Wednesdayâ€™s issues with the Bangla date as Kartik 1. Some online news outlets also showed Kartik 1 as the Bangla date.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The year 1426 is under way in line with the Bangla calendar.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">In the old Bangla calendar, the first five months had 31 days and the remaining seven months 30, with Falgun, the 11th month, having an additional day in the leap year.&nbsp;&nbsp;</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The first six months will be with 31 days, Falgun 29 days (30 days in leap year), and the rest five months will have 30 days in line with the revised calendar.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The public administration ministry had issued a circular notifying the change following recommendations by a special committee of the Bangla Academy, according to Mobarak Hossain, a director at the academy.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The committee headed by retired Dhaka University physicist Professor Ajoy Roy was formed in 2015.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">â€œIt has been done accommodating a myriad of demands,â€ Mobarak said.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The Language Martyrsâ€™ Day of Feb 21, Independence Day of Mar 26 and Victory Day of Dec 16 will fall on Falgun 8, Chaitra 12, and Poush 1, respectively of the Bangla calendar for next 100 years now as they did in the Gregorian calendar years 1952 and 1971, according to Mobarak.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">In the old Bangla calendar, Feb 21 fell on Falgun 9 earlier this year. After the change Dec 16 will fall on Poush 1, not on the second day of the month.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">Mobarak said the Bangla New Year will also fall on Apr 14, Rabindra Joyanti of Baishakh 25 on May 8 and Nazrul Joyanti of Jaishthha 11 on May 25.</p><p style=\"margin-bottom: 15px; padding: 0px; line-height: 19px; border: 0px; outline-style: initial; outline-width: 0px; vertical-align: baseline; background: transparent; overflow: visible;\">The Bangla calendar had been revised twice earlier. Astrophysicist Dr Meghnad Saha led the first revision in the 1950s and Dr Muhammad Shahidullah in 1963.</p></div></div></div>', '2019-12-13 23:18:15', NULL, 1, 'Bangladesh-reworks-Bangla-calendar-to-match-national-days-with-West', '62bf1edb36141f114521ec4bb4175579.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubcategory`
--

CREATE TABLE `tblsubcategory` (
  `SubCategoryId` int(11) NOT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `Subcategory` varchar(255) DEFAULT NULL,
  `SubCatDescription` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL,
  `Is_Active` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubcategory`
--

INSERT INTO `tblsubcategory` (`SubCategoryId`, `CategoryId`, `Subcategory`, `SubCatDescription`, `PostingDate`, `UpdationDate`, `Is_Active`) VALUES
(11, 9, 'Bangladesh', 'national', '2019-12-13 22:01:22', NULL, 1),
(12, 9, 'politics', 'politics', '2019-12-13 22:01:49', NULL, 1),
(13, 9, 'Crime', 'Crime', '2019-12-13 22:02:06', NULL, 1),
(14, 9, 'Economy', 'Economy', '2019-12-13 22:02:34', NULL, 1),
(15, 9, 'Environment', 'Environment', '2019-12-13 22:03:03', NULL, 1),
(16, 10, 'North America', 'North America', '2019-12-13 22:03:25', NULL, 1),
(17, 13, 'Cricket', 'cricket', '2019-12-13 22:04:01', NULL, 1),
(18, 13, 'Football', 'Football', '2019-12-13 22:04:14', NULL, 1),
(19, 13, 'Tennis', 'Tennis\r\n', '2019-12-13 22:04:33', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomments`
--
ALTER TABLE `tblcomments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblposts`
--
ALTER TABLE `tblposts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  ADD PRIMARY KEY (`SubCategoryId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tblcomments`
--
ALTER TABLE `tblcomments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblposts`
--
ALTER TABLE `tblposts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblsubcategory`
--
ALTER TABLE `tblsubcategory`
  MODIFY `SubCategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
