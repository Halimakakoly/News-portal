
                <footer class="footer text-right">
                   2019 © Developed by The Cloud Team.
                </footer>
